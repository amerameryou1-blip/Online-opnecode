import type { Config } from "./config";

/**
 * Builds the single Kaggle cell. Uses String.raw so Python escapes (\n, \r, \.)
 * survive untouched. Only ${...} placeholders are substituted.
 *
 * Fixes vs. the old cell (which hung in step 4):
 *  - daemons (tmux/ttyd/cloudflared/http.server) are started with Popen + start_new_session
 *    and NO pipes back to the notebook -> subprocess.run(capture_output) can never block on them
 *  - every foreground command has a timeout, every curl has --max-time
 *  - `pkill -f cloudflared` used to kill its *own* shell (the command line contained the word) -> [c] trick
 *  - ttyd download URL was wrong (tsl0928 -> tsl0922) and is now pinned
 *  - cloudflared forced to http2 (Kaggle blocks QUIC/UDP -> long retries before)
 *  - services launched via `tmux send-keys` into a live bash so a crash leaves the error visible
 *  - fallback to `opencode serve` if `opencode web` doesn't answer, progress dots while waiting
 */
export function buildCell(cfg: Config): string {
  const extraEnv: Record<string, string> = {};
  for (const [k, v] of Object.entries(cfg.extraEnv)) if (v.trim()) extraEnv[k] = v.trim();
  const extraEnvJson = JSON.stringify(extraEnv);
  const token = cfg.token.trim();
  const repo = cfg.repo.trim();
  const saveEvery = Math.max(1, Math.round(cfg.saveEveryMin));
  const deadline = Math.min(11.8, Math.max(0.2, cfg.deadlineH));

  return String.raw`# ============================================================
#  OpenCode on Kaggle CPU — ONE CELL — full remote control   (v2 · hang-proof)
#  • ttyd   : real terminal in the browser (mouse, paste) -> tmux (windows: web / tui / shell)
#  • opencode web UI        • file browser (download anything from /kaggle/working)
#  • 3 Cloudflare quick tunnels (secret random URLs) -> live.json on Hugging Face
#  • your control website polls live.json and auto-connects
#  • state -> HF every ${saveEvery} min + final save before the 12 h limit
#  Interactive: cell returns after setup, everything keeps running in tmux.
#  Headless 12 h: Save Version -> "Save & Run All" (batch mode keeps the cell alive).
# ============================================================
import os, sys, subprocess, time, datetime, threading, json, secrets, re, tarfile, socket, shutil, shlex

HF_TOKEN       = "${token}"
HF_REPO        = "${repo}"            # "user/name" or just "name" (created under your HF account)
SAVE_EVERY_MIN = ${saveEvery}
DEADLINE_H     = ${deadline}
P_WEB, P_TTY, P_FILES = 4096, 7681, 8088
COLS, ROWS = 120, 36
TTYD_VER = "1.7.7"
EXTRA_ENV = ${extraEnvJson}   # extra provider keys injected from the control site settings
for _k, _v in EXTRA_ENV.items():
    if _v: os.environ[_k] = _v

T0 = time.time()
os.environ.update({"HF_TOKEN": HF_TOKEN, "HF_HUB_DISABLE_XET": "1", "HF_HUB_DISABLE_PROGRESS_BARS": "1", "HF_HUB_DISABLE_TELEMETRY": "1"})
HOME, OUT = os.path.expanduser("~"), "/kaggle/working"
WORK = f"{OUT}/workspace"; os.makedirs(WORK, exist_ok=True)
IS_BATCH = os.environ.get("KAGGLE_KERNEL_RUN_TYPE", "Interactive").lower() == "batch"
SECRET = secrets.token_urlsafe(10)
DEVNULL = subprocess.DEVNULL
os.environ["PATH"] = f"{HOME}/.opencode/bin:{HOME}/.local/bin:/usr/local/bin:" + os.environ["PATH"]

def log(*a): print(f"[{datetime.datetime.now():%H:%M:%S}]", *a, flush=True)

def sh(cmd, timeout=120):
    """Short foreground command. Never inherits notebook stdin, always times out."""
    try:
        r = subprocess.run(cmd, shell=True, text=True, executable="/bin/bash", stdin=DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        return r.stdout or ""
    except subprocess.TimeoutExpired:
        return f"[timeout after {timeout}s]"

def bg(cmd, logfile):
    """Long-running daemon: own session, output to a file, NO pipe back to the notebook.
    (A daemon holding the notebook's stdout pipe is exactly what made the old cell hang.)"""
    f = open(logfile, "ab", buffering=0)
    return subprocess.Popen(cmd, shell=True, executable="/bin/bash", stdin=DEVNULL, stdout=f, stderr=f,
                            start_new_session=True, close_fds=True)

def port_open(port, host="127.0.0.1"):
    with socket.socket() as s:
        s.settimeout(1)
        return s.connect_ex((host, port)) == 0

def wait_for(pred, secs, label):
    print(f"   waiting for {label} ", end="", flush=True)
    for i in range(secs):
        try:
            if pred(): print(" ok", flush=True); return True
        except Exception: pass
        if i % 3 == 0: print(".", end="", flush=True)
        time.sleep(1)
    print(f" gave up after {secs}s", flush=True); return False

def kill_old():
    # pkill -f 'cloudflared' would match (and kill) the very shell running it -> [c] regex trick
    sh(f"tmux kill-server 2>/dev/null; pkill -f '[c]loudflared tunnel'; pkill -f '[t]tyd '; pkill -f '[h]ttp.server {P_FILES}'; true", timeout=20)
    time.sleep(1)

# ------------------------------------------------------------------ 1/6
log("== 1/6 deps ==")
if not shutil.which("tmux"):
    sh("apt-get install -y -qq tmux fonts-dejavu-core >/dev/null 2>&1 || (apt-get update -qq >/dev/null 2>&1 && apt-get install -y -qq tmux fonts-dejavu-core >/dev/null 2>&1); true", timeout=400)
sh(f"{sys.executable} -m pip install -q pyte pillow 'huggingface_hub>=0.25' >/dev/null 2>&1; {sys.executable} -m pip uninstall -y -q hf_xet hf-xet >/dev/null 2>&1; true", timeout=400)
for m in [k for k in list(sys.modules) if k.startswith(("huggingface_hub", "hf_xet"))]: del sys.modules[m]
if not os.path.exists("/usr/local/bin/cloudflared"):
    sh("curl -fsSL --retry 3 --max-time 180 -o /usr/local/bin/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 && chmod +x /usr/local/bin/cloudflared", timeout=240)
if not os.path.exists("/usr/local/bin/ttyd"):
    sh(f"curl -fsSL --retry 3 --max-time 180 -o /usr/local/bin/ttyd https://github.com/tsl0922/ttyd/releases/download/{TTYD_VER}/ttyd.x86_64 && chmod +x /usr/local/bin/ttyd", timeout=240)
log("tmux:", sh("tmux -V").strip() or "MISSING", "| ttyd:", sh("ttyd --version").strip() or "MISSING",
    "| cloudflared:", (sh("cloudflared --version").strip().split(" (")[0] or "MISSING"), "| mode:", "BATCH" if IS_BATCH else "INTERACTIVE")

# ------------------------------------------------------------------ 2/6
log("== 2/6 Hugging Face storage ==")
from huggingface_hub import HfApi, hf_hub_download, create_repo, whoami
api = HfApi(token=HF_TOKEN); USER = whoami(token=HF_TOKEN)["name"]
REPO = HF_REPO if "/" in HF_REPO else f"{USER}/{HF_REPO}"
create_repo(REPO, repo_type="dataset", private=True, exist_ok=True, token=HF_TOKEN)
STATE_DIRS = [f"{HOME}/.local/share/opencode", f"{HOME}/.config/opencode", WORK]
for p in STATE_DIRS: os.makedirs(p, exist_ok=True)
EXCLUDE = ("/bin/", "/log/", "/node_modules/", "/.git/", "/cache/", "/.venv/", "/__pycache__/")
try:
    tb = hf_hub_download(REPO, "state.tar.gz", repo_type="dataset", token=HF_TOKEN, force_download=True)
    with tarfile.open(tb) as t:
        try: t.extractall("/", filter="fully_trusted")
        except TypeError: t.extractall("/")
    log(f"restored state.tar.gz ({os.path.getsize(tb)//1024} KB)")
except Exception as e: log("no previous state:", type(e).__name__)

LIVE = {"terminal": None, "web": None, "files": None, "started": None, "deadline_utc": None, "last_save": None,
        "mode": "batch" if IS_BATCH else "interactive", "ended": None, "opencode_version": None,
        "host": socket.gethostname(), "heartbeat": None}
def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z"
def push_live():
    LIVE["heartbeat"] = now()
    try: api.upload_file(path_or_fileobj=json.dumps(LIVE, indent=1).encode(), path_in_repo="live.json", repo_id=REPO, repo_type="dataset", token=HF_TOKEN, commit_message="live")
    except Exception as e: log("live.json push failed:", type(e).__name__, str(e)[:100])
_lock = threading.Lock()
def save_to_hf(msg="autosave"):
    with _lock:
        tmp = "/tmp/state.tar.gz"
        with tarfile.open(tmp, "w:gz") as t:
            for d in STATE_DIRS:
                if os.path.isdir(d): t.add(d, arcname=d.lstrip("/"), filter=lambda ti: None if any(x in "/"+ti.name+"/" for x in EXCLUDE) else ti)
        for i in range(3):
            try:
                api.upload_file(path_or_fileobj=tmp, path_in_repo="state.tar.gz", repo_id=REPO, repo_type="dataset", token=HF_TOKEN, commit_message=f"{msg} {datetime.datetime.utcnow():%Y-%m-%d %H:%M}Z")
                LIVE["last_save"] = now(); push_live()
                log(f"saved {os.path.getsize(tmp)//1024} KB -> HF ({msg})"); return True
            except Exception as e: log("save failed:", type(e).__name__, str(e)[:120]); time.sleep(10)
        return False

# ------------------------------------------------------------------ 3/6
log("== 3/6 install OpenCode ==")
if not shutil.which("opencode"):
    sh("curl -fsSL https://opencode.ai/install | bash", timeout=600)
OC = shutil.which("opencode") or f"{HOME}/.opencode/bin/opencode"
OC_VER = sh(f"{OC} --version", timeout=30).strip().splitlines()[-1:] or ["NOT FOUND"]
LIVE["opencode_version"] = OC_VER[0]; log("opencode:", OC_VER[0])

# ------------------------------------------------------------------ 4/6
log("== 4/6 services + tunnels ==")
kill_old()
ENV_FILE = f"{HOME}/.oc_env"
with open(ENV_FILE, "w") as f:
    f.write("export TERM=xterm-256color COLORTERM=truecolor\n")
    for k in ["OPENAI_API_KEY","ANTHROPIC_API_KEY","OPENROUTER_API_KEY","GROQ_API_KEY","GEMINI_API_KEY","HF_TOKEN","PATH"]:
        if os.environ.get(k): f.write(f"export {k}={shlex.quote(os.environ[k])}\n")
open(f"{HOME}/.tmux.conf","w").write("set -g mouse on\nset -g history-limit 50000\nset -g default-terminal 'tmux-256color'\nset -ga terminal-overrides ',*:Tc'\nset -g status-style bg=colour236,fg=colour250\nset -g escape-time 10\nsetw -g aggressive-resize on\n")

# window 0 "web": opencode server (the agent lives here, independent of any browser)
sh(f"tmux new-session -d -s oc -n web -x {COLS} -y {ROWS} -c {WORK}", timeout=30)
sh(f"tmux send-keys -t oc:web {shlex.quote(f'source {ENV_FILE}; cd {WORK}; {OC} web --port {P_WEB} --hostname 0.0.0.0 2>&1 | tee {OUT}/opencode_web.log')} Enter")
def healthy(): return sh(f"curl -s --max-time 3 http://127.0.0.1:{P_WEB}/global/health", timeout=8).startswith("{")
if not wait_for(healthy, 60, "opencode web"):
    log("'opencode web' not answering -> falling back to 'opencode serve'")
    sh("tmux send-keys -t oc:web C-c"); time.sleep(1)
    sh(f"tmux send-keys -t oc:web {shlex.quote(f'{OC} serve --port {P_WEB} --hostname 0.0.0.0 2>&1 | tee -a {OUT}/opencode_web.log')} Enter")
    wait_for(healthy, 45, "opencode serve")
log("server:", sh(f"curl -s --max-time 3 http://127.0.0.1:{P_WEB}/global/health", timeout=8).strip() or "NOT UP (open the 'web' tmux window in the terminal to see the error)")

# window 1 "tui": OpenCode TUI attached to that server | window 2 "shell": plain bash
sh(f"tmux new-window -t oc -n tui -c {WORK}")
sh(f"tmux send-keys -t oc:tui {shlex.quote(f'source {ENV_FILE}; {OC} attach http://127.0.0.1:{P_WEB} || {OC}')} Enter")
sh(f"tmux new-window -t oc -n shell -c {WORK}")
sh(f"tmux send-keys -t oc:shell {shlex.quote(f'source {ENV_FILE}; clear')} Enter")
sh("tmux select-window -t oc:tui")

# ttyd: browser terminal -> tmux (writable, mouse on, secret base path)
THEME = json.dumps({"background": "#0c0c0c", "foreground": "#d4d4d4"})
bg(f"ttyd -W -p {P_TTY} -b /{SECRET} -t fontSize=14 -t disableLeaveAlert=true -t {shlex.quote('theme=' + THEME)} tmux new-session -A -s oc", f"{OUT}/ttyd.log")
# file browser / downloads for /kaggle/working
bg(f"cd {OUT} && {sys.executable} -m http.server {P_FILES} --bind 127.0.0.1", f"{OUT}/files.log")
wait_for(lambda: port_open(P_TTY), 20, "ttyd :%d" % P_TTY)
wait_for(lambda: port_open(P_FILES), 10, "files :%d" % P_FILES)

def tunnel(port, name):
    lf = f"{OUT}/cf_{name}.log"; open(lf, "w").close()
    return bg(f"cloudflared tunnel --no-autoupdate --protocol http2 --edge-ip-version auto --url http://127.0.0.1:{port}", lf)
PORTS = [(P_TTY, "terminal"), (P_WEB, "web"), (P_FILES, "files")]
def grab():
    for port, name in PORTS:
        if not LIVE[name]:
            try: txt = open(f"{OUT}/cf_{name}.log").read()
            except Exception: txt = ""
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", txt)
            if m: LIVE[name] = m.group(0) + (f"/{SECRET}/" if name == "terminal" else "/")
    return all(LIVE[n] for _, n in PORTS)
for port, name in PORTS: tunnel(port, name)
if not wait_for(grab, 90, "cloudflare tunnel URLs"):
    for port, name in PORTS:
        if not LIVE[name]:
            log(f"retrying tunnel '{name}' (log tail: {sh(f'tail -n 3 {OUT}/cf_{name}.log').strip()[-200:]})")
            sh(f"pkill -f '[c]loudflared.*127.0.0.1:{port}'; true"); tunnel(port, name)
    wait_for(grab, 90, "tunnel retry")

LIVE["started"] = now()
LIVE["deadline_utc"] = (datetime.datetime.utcnow() + datetime.timedelta(hours=DEADLINE_H)).isoformat(timespec="seconds") + "Z"
push_live()
print("\n" + "=" * 70)
for _, k in PORTS: print(f"  {k:9s}: {LIVE[k] or 'FAILED'}")
print(f"  live.json : https://huggingface.co/datasets/{REPO}/blob/main/live.json")
print("=" * 70 + "\n", flush=True)

# ------------------------------------------------------------------ 5/6
log("== 5/6 screenshot ==")
import pyte
from PIL import Image, ImageDraw, ImageFont
from IPython.display import display, Image as IPImage
def _font(b=False, s=16):
    p = f"/usr/share/fonts/truetype/dejavu/DejaVuSansMono{'-Bold' if b else ''}.ttf"
    return ImageFont.truetype(p, s) if os.path.exists(p) else ImageFont.load_default()
PAL = {"black":"#1e1e1e","red":"#f14c4c","green":"#23d18b","brown":"#f5f543","blue":"#3b8eea","magenta":"#d670d6","cyan":"#29b8db","white":"#cccccc","brightblack":"#666666","brightred":"#ff7b7b","brightgreen":"#89d185","brightyellow":"#f9f1a5","brightblue":"#6fa8ff","brightmagenta":"#ff9ff3","brightcyan":"#8be9fd","brightwhite":"#ffffff"}
def _col(c, d):
    if not c or c == "default": return d
    if c in PAL: return PAL[c]
    if len(c) == 6:
        try: int(c, 16); return "#" + c
        except ValueError: pass
    return d
def shot(name=None, show=True, upload=True, window="tui"):
    ansi = sh(f"tmux capture-pane -p -e -t oc:{window}", timeout=15)
    scr = pyte.Screen(COLS, ROWS); pyte.Stream(scr).feed(ansi.replace("\n", "\r\n"))
    fn, fb = _font(), _font(True); cw = int(fn.getbbox("M")[2]) or 10; ch = 20; pad = 14
    img = Image.new("RGB", (COLS*cw + 2*pad, ROWS*ch + 2*pad), "#0c0c0c"); dr = ImageDraw.Draw(img)
    for y in range(ROWS):
        for x in range(COLS):
            c = scr.buffer[y][x]; fg, bg_ = _col(c.fg, "#d4d4d4"), _col(c.bg, "#0c0c0c")
            if c.reverse: fg, bg_ = bg_, fg
            X, Y = pad + x*cw, pad + y*ch
            if bg_ != "#0c0c0c": dr.rectangle([X, Y, X+cw, Y+ch], fill=bg_)
            if c.data and c.data != " ": dr.text((X, Y), c.data, font=fb if c.bold else fn, fill=fg)
    name = name or f"opencode_{datetime.datetime.now():%Y%m%d_%H%M%S}.png"; path = os.path.join(OUT, name); img.save(path); log("saved", path)
    if show: display(IPImage(path))
    if upload:
        try: api.upload_file(path_or_fileobj=path, path_in_repo=f"screenshots/{name}", repo_id=REPO, repo_type="dataset", token=HF_TOKEN)
        except Exception as e: log("upload failed:", type(e).__name__)
    return path
def send(keys, enter=True, wait=2, window="tui"):
    subprocess.run(["tmux", "send-keys", "-t", f"oc:{window}", "-l", keys], stdin=DEVNULL, timeout=10)
    if enter: subprocess.run(["tmux", "send-keys", "-t", f"oc:{window}", "Enter"], stdin=DEVNULL, timeout=10)
    time.sleep(wait)
def status():
    for _, k in PORTS: print(f"  {k:9s}: {LIVE[k]}")
    print("  windows  :", sh("tmux list-windows -t oc -F '#I:#W'").replace("\n", " "))
try: shot("opencode_terminal_screenshot.png")
except Exception as e: log("screenshot failed:", type(e).__name__, str(e)[:100])

# ------------------------------------------------------------------ 6/6
log("== 6/6 autosave ==")
save_to_hf("initial sync")
STOP = threading.Event()
def _loop():
    last_save, last_beat = time.time(), time.time()
    while not STOP.is_set():
        time.sleep(20)
        try:
            if (time.time() - T0) / 3600 >= DEADLINE_H:
                log("[deadline] final save"); save_to_hf("FINAL before 12h limit")
                LIVE.update({"terminal": None, "web": None, "files": None, "ended": now()}); push_live(); STOP.set(); break
            if time.time() - last_save >= SAVE_EVERY_MIN * 60: save_to_hf("autosave"); last_save = time.time()
            elif time.time() - last_beat >= 300: push_live(); last_beat = time.time()   # heartbeat for the site
            if not port_open(P_TTY): log("ttyd died -> restarting"); bg(f"ttyd -W -p {P_TTY} -b /{SECRET} -t fontSize=14 -t disableLeaveAlert=true -t {shlex.quote('theme=' + THEME)} tmux new-session -A -s oc", f"{OUT}/ttyd.log")
        except Exception as e: log("loop error:", type(e).__name__, str(e)[:100])
threading.Thread(target=_loop, daemon=True).start()
log(f"autosave every {SAVE_EVERY_MIN} min, final save at {DEADLINE_H} h. Helpers: send('text'), shot(), save_to_hf(), status()")
if IS_BATCH:
    log("BATCH: staying alive until deadline (you can close the browser).")
    while not STOP.is_set(): time.sleep(30)
    sh("tmux kill-server; pkill -f '[c]loudflared tunnel'; pkill -f '[t]tyd '; true", timeout=20); log("done.")
else:
    log("INTERACTIVE: cell returned; everything keeps running in tmux while this notebook session is alive. Open your control website.")
`;
}

/** Wraps the cell in a minimal .ipynb so it can be uploaded to Kaggle directly. */
export function buildNotebook(cfg: Config): string {
  const src = buildCell(cfg);
  const lines = src.split("\n").map((l, i, a) => (i < a.length - 1 ? l + "\n" : l));
  return JSON.stringify(
    {
      cells: [
        {
          cell_type: "markdown",
          metadata: {},
          source: [
            "# OpenCode @ Kaggle — remote desktop\n",
            "Settings → Accelerator: **None (CPU)**, Internet: **ON**. Run the cell below. ",
            "For a 12 h headless session use *Save Version → Save & Run All*.",
          ],
        },
        { cell_type: "code", execution_count: null, metadata: {}, outputs: [], source: lines },
      ],
      metadata: {
        kernelspec: { display_name: "Python 3", language: "python", name: "python3" },
        language_info: { name: "python" },
      },
      nbformat: 4,
      nbformat_minor: 5,
    },
    null,
    1,
  );
}
