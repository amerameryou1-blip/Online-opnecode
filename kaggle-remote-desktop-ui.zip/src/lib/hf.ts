import type { Live } from "./config";

export function hfHeaders(token: string): HeadersInit {
  const t = token.trim();
  return t ? { Authorization: `Bearer ${t}` } : {};
}

export function resolveUrl(repo: string, path: string) {
  return `https://huggingface.co/datasets/${repo.trim()}/resolve/main/${path}?ts=${Date.now()}`;
}

export function repoPageUrl(repo: string, path = "") {
  return `https://huggingface.co/datasets/${repo.trim()}${path ? `/blob/main/${path}` : ""}`;
}

export async function fetchLive(repo: string, token: string): Promise<Live> {
  const r = await fetch(resolveUrl(repo, "live.json"), { headers: hfHeaders(token), cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}${r.status === 404 ? " (no live.json yet — run the cell)" : r.status === 401 ? " (bad token)" : ""}`);
  return (await r.json()) as Live;
}

export interface HfFile {
  path: string;
  size: number;
  type: string;
  lastCommit?: { date?: string };
}

export async function listScreenshots(repo: string, token: string): Promise<HfFile[]> {
  const r = await fetch(`https://huggingface.co/api/datasets/${repo.trim()}/tree/main/screenshots?expand=true&ts=${Date.now()}`, {
    headers: hfHeaders(token),
    cache: "no-store",
  });
  if (r.status === 404) return [];
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const j = (await r.json()) as HfFile[];
  return j.filter((f) => f.type === "file" && /\.(png|jpg|jpeg)$/i.test(f.path));
}

export async function fetchBlobUrl(repo: string, token: string, path: string): Promise<string> {
  const r = await fetch(resolveUrl(repo, path), { headers: hfHeaders(token), cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return URL.createObjectURL(await r.blob());
}

export async function whoami(token: string): Promise<string> {
  const r = await fetch("https://huggingface.co/api/whoami-v2", { headers: hfHeaders(token) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const j = await r.json();
  return j.name as string;
}

export function fmtTime(iso?: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "—" : d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function fmtDateTime(iso?: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "—" : d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export function fmtDuration(sec: number) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  if (m > 0) return `${m}m ${String(s).padStart(2, "0")}s`;
  return `${s}s`;
}

export function ago(iso?: string | null) {
  if (!iso) return "—";
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "—";
  return fmtDuration((Date.now() - t) / 1000) + " ago";
}
