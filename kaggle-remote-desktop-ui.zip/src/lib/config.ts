export type ExtraKey =
  | "OPENAI_API_KEY"
  | "ANTHROPIC_API_KEY"
  | "OPENROUTER_API_KEY"
  | "GROQ_API_KEY"
  | "GEMINI_API_KEY";

export const EXTRA_KEYS: ExtraKey[] = [
  "OPENAI_API_KEY",
  "ANTHROPIC_API_KEY",
  "OPENROUTER_API_KEY",
  "GROQ_API_KEY",
  "GEMINI_API_KEY",
];

export interface Config {
  token: string;
  repo: string; // user/name
  pollSec: number;
  saveEveryMin: number;
  deadlineH: number;
  notebookUrl: string;
  notify: boolean;
  extraEnv: Record<ExtraKey, string>;
}

export const DEFAULT_CONFIG: Config = {
  token: "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",
  repo: "amer224/opencode-kaggle-state",
  pollSec: 20,
  saveEveryMin: 15,
  deadlineH: 11.5,
  notebookUrl: "",
  notify: true,
  extraEnv: {
    OPENAI_API_KEY: "",
    ANTHROPIC_API_KEY: "",
    OPENROUTER_API_KEY: "",
    GROQ_API_KEY: "",
    GEMINI_API_KEY: "",
  },
};

const KEY = "oc_cfg_v2";

export function loadConfig(): Config {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const j = JSON.parse(raw);
      return {
        ...DEFAULT_CONFIG,
        ...j,
        extraEnv: { ...DEFAULT_CONFIG.extraEnv, ...(j.extraEnv || {}) },
      };
    }
    // migrate from the old single-file page
    const tok = localStorage.getItem("oc_tok");
    const repo = localStorage.getItem("oc_repo");
    if (tok || repo) {
      return { ...DEFAULT_CONFIG, token: tok || DEFAULT_CONFIG.token, repo: repo || DEFAULT_CONFIG.repo };
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_CONFIG;
}

export function saveConfig(c: Config) {
  localStorage.setItem(KEY, JSON.stringify(c));
}

export interface Live {
  terminal: string | null;
  web: string | null;
  files: string | null;
  started: string | null;
  deadline_utc: string | null;
  last_save: string | null;
  mode: "batch" | "interactive" | string | null;
  ended: string | null;
  opencode_version?: string | null;
  host?: string | null;
  heartbeat?: string | null;
}

export const EMPTY_LIVE: Live = {
  terminal: null,
  web: null,
  files: null,
  started: null,
  deadline_utc: null,
  last_save: null,
  mode: null,
  ended: null,
};

export type ViewId = "term" | "web" | "files" | "shots" | "cell" | "activity";

export const VIEWS: { id: ViewId; label: string; hint: string }[] = [
  { id: "term", label: "Terminal", hint: "ttyd → tmux (TUI, shell)" },
  { id: "web", label: "OpenCode UI", hint: "opencode web interface" },
  { id: "files", label: "Files", hint: "/kaggle/working browser" },
  { id: "shots", label: "Screenshots", hint: "rendered terminal captures" },
  { id: "cell", label: "Kaggle cell", hint: "one-cell installer" },
  { id: "activity", label: "Activity", hint: "poll log & raw live.json" },
];

export function mask(t: string) {
  if (!t) return "—";
  if (t.length <= 10) return "•".repeat(t.length);
  return t.slice(0, 5) + "…" + t.slice(-4);
}
