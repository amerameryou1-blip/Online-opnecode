import { useCallback, useEffect, useRef, useState } from "react";
import { EMPTY_LIVE, type Config, type Live } from "../lib/config";
import { fetchLive } from "../lib/hf";

export type Status = "connecting" | "live" | "offline" | "ended" | "error";

export interface LogEntry {
  t: number;
  kind: "info" | "ok" | "warn" | "err";
  msg: string;
}

export function useLive(cfg: Config) {
  const [live, setLive] = useState<Live>(EMPTY_LIVE);
  const [status, setStatus] = useState<Status>("connecting");
  const [error, setError] = useState<string>("");
  const [lastPoll, setLastPoll] = useState<number>(0);
  const [nextPoll, setNextPoll] = useState<number>(0);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [polling, setPolling] = useState(false);
  const prev = useRef<Live>(EMPTY_LIVE);
  const prevStatus = useRef<Status>("connecting");
  const timer = useRef<number | null>(null);
  const cfgRef = useRef(cfg);
  cfgRef.current = cfg;

  const push = useCallback((kind: LogEntry["kind"], msg: string) => {
    setLog((l) => [{ t: Date.now(), kind, msg }, ...l].slice(0, 300));
  }, []);

  const poll = useCallback(async () => {
    const c = cfgRef.current;
    setPolling(true);
    try {
      const j = await fetchLive(c.repo, c.token);
      const p = prev.current;
      for (const k of ["terminal", "web", "files"] as const) {
        if (j[k] !== p[k]) push(j[k] ? "ok" : "warn", `${k} → ${j[k] ?? "offline"}`);
      }
      if (j.last_save && j.last_save !== p.last_save) push("info", `state saved to HF (${new Date(j.last_save).toLocaleTimeString()})`);
      const on = !!j.terminal || !!j.web;
      const st: Status = on ? "live" : j.ended ? "ended" : "offline";
      if (st !== prevStatus.current) {
        push(st === "live" ? "ok" : st === "ended" ? "warn" : "info", `session is ${st}${j.mode ? ` · ${j.mode}` : ""}`);
        if (st === "live" && c.notify && "Notification" in window && Notification.permission === "granted" && prevStatus.current !== "connecting") {
          try {
            new Notification("OpenCode @ Kaggle is live", { body: "Tunnels are up — terminal is ready." });
          } catch {
            /* ignore */
          }
        }
      }
      prev.current = j;
      prevStatus.current = st;
      setLive(j);
      setStatus(st);
      setError("");
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (prevStatus.current !== "error" || error !== msg) push("err", `HF fetch failed: ${msg}`);
      prevStatus.current = "error";
      setStatus("error");
      setError(msg);
    } finally {
      setPolling(false);
      setLastPoll(Date.now());
      setNextPoll(Date.now() + cfgRef.current.pollSec * 1000);
    }
  }, [push, error]);

  // (re)start polling when repo/token/interval change
  useEffect(() => {
    if (timer.current) window.clearInterval(timer.current);
    prev.current = EMPTY_LIVE;
    prevStatus.current = "connecting";
    setStatus("connecting");
    push("info", `polling ${cfg.repo} every ${cfg.pollSec}s`);
    void poll();
    timer.current = window.setInterval(() => void poll(), cfg.pollSec * 1000);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cfg.repo, cfg.token, cfg.pollSec]);

  // poll immediately when the tab becomes visible again
  useEffect(() => {
    const h = () => {
      if (document.visibilityState === "visible") void poll();
    };
    document.addEventListener("visibilitychange", h);
    return () => document.removeEventListener("visibilitychange", h);
  }, [poll]);

  const clearLog = useCallback(() => setLog([]), []);

  return { live, status, error, lastPoll, nextPoll, polling, log, poll, push, clearLog };
}
