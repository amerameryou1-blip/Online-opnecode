import { useEffect, useState } from "react";
import { DEFAULT_CONFIG, EXTRA_KEYS, type Config } from "../lib/config";
import { whoami } from "../lib/hf";
import { Btn, Field, Icon, inputCls } from "./ui";

interface Props {
  open: boolean;
  cfg: Config;
  onClose: () => void;
  onSave: (c: Config) => void;
}

export function SettingsDrawer({ open, cfg, onClose, onSave }: Props) {
  const [d, setD] = useState<Config>(cfg);
  const [test, setTest] = useState<string>("");
  const [showTok, setShowTok] = useState(false);
  useEffect(() => {
    if (open) {
      setD(cfg);
      setTest("");
    }
  }, [open, cfg]);

  if (!open) return null;
  const set = <K extends keyof Config>(k: K, v: Config[K]) => setD((x) => ({ ...x, [k]: v }));

  const runTest = async () => {
    setTest("testing…");
    try {
      const name = await whoami(d.token);
      const r = await fetch(`https://huggingface.co/api/datasets/${d.repo.trim()}`, { headers: { Authorization: `Bearer ${d.token.trim()}` } });
      setTest(`token OK (${name}) · repo ${r.ok ? "found" : `not found yet (HTTP ${r.status}) — the cell creates it`}`);
    } catch (e) {
      setTest(`token invalid: ${e instanceof Error ? e.message : e}`);
    }
  };

  const askNotify = async () => {
    if (!("Notification" in window)) return setTest("notifications unsupported in this browser");
    const p = await Notification.requestPermission();
    setTest(`notification permission: ${p}`);
  };

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/50" onMouseDown={onClose}>
      <div className="flex h-full w-full max-w-md flex-col border-l border-neutral-800 bg-neutral-950 shadow-2xl" onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 border-b border-neutral-800 px-4 py-3">
          <Icon.Settings />
          <span className="text-sm font-semibold text-neutral-100">Settings</span>
          <Btn variant="ghost" className="ml-auto" onClick={onClose}><Icon.Close /></Btn>
        </div>

        <div className="min-h-0 flex-1 space-y-5 overflow-auto px-4 py-4">
          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Hugging Face</h3>
            <Field label="Token" hint="write access — used by the cell to push state and by this page to read live.json">
              <div className="flex gap-1">
                <input className={inputCls} type={showTok ? "text" : "password"} value={d.token} onChange={(e) => set("token", e.target.value)} placeholder="hf_…" />
                <Btn onClick={() => setShowTok((s) => !s)}>{showTok ? "hide" : "show"}</Btn>
              </div>
            </Field>
            <Field label="Dataset repo" hint="user/name — private dataset, created automatically by the cell">
              <input className={inputCls} value={d.repo} onChange={(e) => set("repo", e.target.value)} placeholder="user/opencode-kaggle-state" />
            </Field>
            <div className="flex items-center gap-2">
              <Btn onClick={runTest}>Test connection</Btn>
              <span className="text-[11px] text-neutral-400">{test}</span>
            </div>
          </section>

          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-emerald-400">This page</h3>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Poll interval">
                <select className={inputCls} value={d.pollSec} onChange={(e) => set("pollSec", Number(e.target.value))}>
                  {[10, 20, 30, 60, 120].map((s) => (
                    <option key={s} value={s}>{s}s</option>
                  ))}
                </select>
              </Field>
              <Field label="Notify when live">
                <div className="flex items-center gap-2 pt-1.5">
                  <input type="checkbox" checked={d.notify} onChange={(e) => set("notify", e.target.checked)} className="accent-emerald-500" />
                  <Btn variant="ghost" onClick={askNotify} className="px-1.5"><Icon.Bell /> allow</Btn>
                </div>
              </Field>
            </div>
            <Field label="My Kaggle notebook URL" hint="optional — adds an 'Open my notebook' button">
              <input className={inputCls} value={d.notebookUrl} onChange={(e) => set("notebookUrl", e.target.value)} placeholder="https://www.kaggle.com/code/you/opencode" />
            </Field>
          </section>

          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Kaggle cell parameters</h3>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Autosave every (min)">
                <input className={inputCls} type="number" min={1} max={120} value={d.saveEveryMin} onChange={(e) => set("saveEveryMin", Number(e.target.value))} />
              </Field>
              <Field label="Final save at (hours)">
                <input className={inputCls} type="number" min={0.2} max={11.8} step={0.1} value={d.deadlineH} onChange={(e) => set("deadlineH", Number(e.target.value))} />
              </Field>
            </div>
            <div className="space-y-2">
              <div className="text-[11px] font-medium uppercase tracking-wide text-neutral-400">Extra provider keys (optional, injected into the cell)</div>
              {EXTRA_KEYS.map((k) => (
                <div key={k} className="flex items-center gap-2">
                  <span className="w-40 shrink-0 font-mono text-[11px] text-neutral-400">{k}</span>
                  <input className={inputCls} type="password" value={d.extraEnv[k]} onChange={(e) => set("extraEnv", { ...d.extraEnv, [k]: e.target.value })} placeholder="—" />
                </div>
              ))}
              <p className="text-[11px] text-neutral-500">HF_TOKEN alone already gives OpenCode access to Hugging Face inference models. Keys are stored only in this browser's localStorage.</p>
            </div>
          </section>
        </div>

        <div className="flex items-center gap-2 border-t border-neutral-800 px-4 py-3">
          <Btn variant="primary" onClick={() => onSave({ ...d, token: d.token.trim(), repo: d.repo.trim() })}>
            <Icon.Check /> Save &amp; reconnect
          </Btn>
          <Btn onClick={onClose}>Cancel</Btn>
          <Btn variant="ghost" className="ml-auto" onClick={() => setD(DEFAULT_CONFIG)}>Reset defaults</Btn>
        </div>
      </div>
    </div>
  );
}
