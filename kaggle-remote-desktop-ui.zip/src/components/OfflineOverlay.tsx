import type { Live } from "../lib/config";
import type { Status } from "../hooks/useLive";
import { fmtDateTime } from "../lib/hf";
import { Btn } from "./ui";
import { cn } from "../utils/cn";

interface Props {
  status: Status;
  live: Live;
  error: string;
  pollSec: number;
  onShowCell: () => void;
  onSettings: () => void;
  onPoll: () => void;
}

const steps = [
  { t: "Open a Kaggle notebook", d: "Settings → Accelerator: None (CPU), Internet: ON." },
  { t: "Paste the one cell & run it", d: "Takes ~2–3 min. Progress dots show it is alive. For 12 h headless: Save Version → Save & Run All." },
  { t: "This page connects automatically", d: "Tunnel URLs are written to live.json on Hugging Face and picked up on the next poll." },
];

export function OfflineOverlay({ status, live, error, pollSec, onShowCell, onSettings, onPoll }: Props) {
  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center bg-neutral-950/92 p-6 backdrop-blur-sm">
      <div className="w-full max-w-xl space-y-5">
        <div className="flex items-center gap-3">
          <span className={cn("h-3 w-3 rounded-full", status === "connecting" ? "animate-pulse bg-neutral-500" : status === "ended" ? "bg-amber-500" : status === "error" ? "bg-yellow-400" : "bg-red-500")} />
          <h2 className="text-lg font-semibold text-neutral-100">
            {status === "connecting" && "Connecting to Hugging Face…"}
            {status === "offline" && "No live session"}
            {status === "ended" && "Session ended"}
            {status === "error" && "Can't reach Hugging Face"}
          </h2>
        </div>

        {status === "error" && (
          <div className="rounded-md border border-yellow-900/60 bg-yellow-950/30 p-3 text-xs text-yellow-200">
            <div className="font-mono">{error}</div>
            <div className="mt-1 text-yellow-200/70">
              404 means the cell has never written <code>live.json</code> to this repo. 401 means the token is wrong or lacks read access. Check the repo name and token in settings.
            </div>
          </div>
        )}

        {status === "ended" && (
          <div className="rounded-md border border-amber-900/60 bg-amber-950/30 p-3 text-xs text-amber-100/90">
            The last run finished at <b>{fmtDateTime(live.ended)}</b>. Everything was saved to Hugging Face at <b>{fmtDateTime(live.last_save)}</b> — run the cell again and the state is restored.
          </div>
        )}

        <ol className="space-y-2.5">
          {steps.map((s, i) => (
            <li key={i} className="flex gap-3 rounded-md border border-neutral-800 bg-neutral-900/60 p-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-neutral-800 font-mono text-xs text-emerald-400">{i + 1}</span>
              <div>
                <div className="text-sm font-medium text-neutral-100">{s.t}</div>
                <div className="text-xs text-neutral-400">{s.d}</div>
              </div>
            </li>
          ))}
        </ol>

        <div className="flex flex-wrap items-center gap-2">
          <Btn variant="primary" onClick={onShowCell}>Show the cell</Btn>
          <Btn onClick={onSettings}>Settings</Btn>
          <Btn variant="ghost" onClick={onPoll}>Poll now</Btn>
          <span className="ml-auto text-[11px] text-neutral-500">auto-polling every {pollSec}s</span>
        </div>
      </div>
    </div>
  );
}
