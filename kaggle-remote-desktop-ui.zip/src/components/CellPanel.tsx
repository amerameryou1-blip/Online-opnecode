import { useMemo, useState } from "react";
import { EXTRA_KEYS, mask, type Config } from "../lib/config";
import { buildCell, buildNotebook } from "../lib/cell";
import { Btn, Icon } from "./ui";

function download(name: string, content: string, type = "text/plain") {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([content], { type }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

export function CellPanel({ cfg, onSettings }: { cfg: Config; onSettings: () => void }) {
  const cell = useMemo(() => buildCell(cfg), [cfg]);
  const [copied, setCopied] = useState(false);
  const [wrap, setWrap] = useState(false);
  const lines = useMemo(() => cell.split("\n"), [cell]);
  const extra = EXTRA_KEYS.filter((k) => cfg.extraEnv[k]?.trim());

  const copy = async () => {
    await navigator.clipboard.writeText(cell);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 bg-neutral-900/60 px-3 py-2">
        <div className="mr-2 text-xs text-neutral-300">
          <b className="text-neutral-100">Paste into ONE Kaggle cell</b> · CPU · Internet ON. Headless 12 h: <i>Save Version → Save &amp; Run All</i>.
        </div>
        <Btn variant="primary" onClick={copy}>
          {copied ? <Icon.Check /> : <Icon.Copy />} {copied ? "Copied" : "Copy cell"}
        </Btn>
        <Btn onClick={() => download("opencode_kaggle.py", cell)}>
          <Icon.Download /> .py
        </Btn>
        <Btn onClick={() => download("opencode_kaggle.ipynb", buildNotebook(cfg), "application/json")} title="upload this notebook to Kaggle (File → Import Notebook)">
          <Icon.Download /> .ipynb
        </Btn>
        <a href={cfg.notebookUrl || "https://www.kaggle.com/code"} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-md bg-sky-700/80 px-2.5 py-1 text-xs font-medium text-white hover:bg-sky-600">
          <Icon.External /> {cfg.notebookUrl ? "Open my notebook" : "Kaggle → New notebook"}
        </a>
        <label className="ml-auto flex items-center gap-1.5 text-[11px] text-neutral-400">
          <input type="checkbox" checked={wrap} onChange={(e) => setWrap(e.target.checked)} className="accent-emerald-500" /> wrap
        </label>
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-neutral-800/70 bg-neutral-950 px-3 py-1.5 font-mono text-[11px] text-neutral-400">
        <span>injected from settings →</span>
        <span>HF_TOKEN=<span className="text-neutral-200">{mask(cfg.token)}</span></span>
        <span>HF_REPO=<span className="text-neutral-200">{cfg.repo}</span></span>
        <span>SAVE_EVERY_MIN=<span className="text-neutral-200">{cfg.saveEveryMin}</span></span>
        <span>DEADLINE_H=<span className="text-neutral-200">{cfg.deadlineH}</span></span>
        <span>
          extra keys=<span className="text-neutral-200">{extra.length ? extra.map((k) => k.replace("_API_KEY", "")).join(",") : "none"}</span>
        </span>
        <button onClick={onSettings} className="text-emerald-400 hover:underline">edit</button>
      </div>

      <div className="min-h-0 flex-1 overflow-auto bg-[#0b0b0b]">
        <pre className={`p-3 font-mono text-[11.5px] leading-[1.45] text-neutral-200 ${wrap ? "whitespace-pre-wrap break-all" : "whitespace-pre"}`}>
          {lines.map((l, i) => (
            <div key={i} className="flex hover:bg-neutral-900/70">
              <span className="w-10 shrink-0 select-none pr-3 text-right text-neutral-600">{i + 1}</span>
              <span className={l.trimStart().startsWith("#") ? "text-neutral-500" : ""}>{l}</span>
            </div>
          ))}
        </pre>
      </div>

      <div className="border-t border-neutral-800 bg-neutral-900/60 px-3 py-1.5 text-[11px] text-neutral-400">
        <b className="text-neutral-300">What changed vs. the old cell:</b> daemons no longer share the notebook's stdout pipe (the step-4 hang), every command/curl has a timeout, <code>pkill</code> no longer kills its own shell, ttyd URL fixed &amp; pinned, cloudflared forced to http2 (Kaggle blocks QUIC), <code>opencode serve</code> fallback, progress dots, tunnel retry, heartbeat + ttyd auto-restart.
      </div>
    </div>
  );
}
