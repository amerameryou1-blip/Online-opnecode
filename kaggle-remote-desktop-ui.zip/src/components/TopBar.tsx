import { useEffect, useState } from "react";
import type { Live, ViewId } from "../lib/config";
import { VIEWS } from "../lib/config";
import { fmtDuration } from "../lib/hf";
import type { Status } from "../hooks/useLive";
import { cn } from "../utils/cn";
import { Btn, Icon } from "./ui";

interface Props {
  status: Status;
  error: string;
  live: Live;
  view: ViewId;
  onView: (v: ViewId) => void;
  popUrl: string | null;
  onReload: () => void;
  onFullscreen: () => void;
  onSettings: () => void;
  polling: boolean;
}

const dotCls: Record<Status, string> = {
  connecting: "bg-neutral-500",
  live: "bg-emerald-400 shadow-[0_0_10px_2px_rgba(52,211,153,0.55)]",
  offline: "bg-red-500",
  ended: "bg-amber-500",
  error: "bg-yellow-400",
};

export function TopBar({ status, error, live, view, onView, popUrl, onReload, onFullscreen, onSettings, polling }: Props) {
  const [, tick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const remaining = live.deadline_utc && status === "live" ? (new Date(live.deadline_utc).getTime() - Date.now()) / 1000 : null;
  const total = live.started && live.deadline_utc ? (new Date(live.deadline_utc).getTime() - new Date(live.started).getTime()) / 1000 : 0;
  const pct = remaining !== null && total > 0 ? Math.max(0, Math.min(100, 100 - (remaining / total) * 100)) : 0;

  const statusText =
    status === "connecting"
      ? "connecting…"
      : status === "live"
        ? `live · ${live.mode ?? "?"}`
        : status === "ended"
          ? `session ended ${live.ended ? new Date(live.ended).toLocaleString() : ""}`
          : status === "offline"
            ? "offline — no live session"
            : `HF error: ${error}`;

  return (
    <header className="flex flex-wrap items-center gap-x-3 gap-y-1 border-b border-neutral-800 bg-neutral-900/90 px-3 py-1.5 backdrop-blur">
      <div className="flex items-center gap-2">
        <div className="flex h-6 w-6 items-center justify-center rounded bg-gradient-to-br from-emerald-500 to-teal-700 text-white">
          <Icon.Terminal />
        </div>
        <span className="hidden text-sm font-semibold tracking-tight text-neutral-100 sm:inline">
          OpenCode <span className="text-neutral-500">@</span> Kaggle
        </span>
      </div>

      <div className="flex items-center gap-2 rounded-md bg-neutral-950/60 px-2 py-1 text-xs">
        <span className={cn("h-2 w-2 rounded-full", dotCls[status], polling && "animate-pulse")} />
        <span className={cn("max-w-[260px] truncate", status === "error" ? "text-yellow-300" : "text-neutral-300")} title={statusText}>
          {statusText}
        </span>
        {remaining !== null && (
          <span className="ml-1 flex items-center gap-1.5 border-l border-neutral-800 pl-2 text-neutral-400" title="time until the final save before Kaggle's 12h limit">
            <span className="h-1.5 w-16 overflow-hidden rounded bg-neutral-800">
              <span className={cn("block h-full rounded", pct > 85 ? "bg-red-500" : pct > 65 ? "bg-amber-400" : "bg-emerald-500")} style={{ width: `${pct}%` }} />
            </span>
            <span className="tabular-nums">{fmtDuration(remaining)} left</span>
          </span>
        )}
      </div>

      <nav className="order-last flex w-full items-center gap-1 overflow-x-auto md:order-none md:mx-auto md:w-auto">
        {VIEWS.map((v, i) => {
          const active = v.id === view;
          const hasUrl = v.id === "term" ? !!live.terminal : v.id === "web" ? !!live.web : v.id === "files" ? !!live.files : null;
          return (
            <button
              key={v.id}
              onClick={() => onView(v.id)}
              title={`${v.hint}  (${i + 1})`}
              className={cn(
                "relative flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                active ? "bg-emerald-600/90 text-white" : "text-neutral-300 hover:bg-neutral-800 hover:text-white",
              )}
            >
              {hasUrl !== null && <span className={cn("h-1.5 w-1.5 rounded-full", hasUrl ? "bg-emerald-300" : "bg-neutral-600")} />}
              {v.label}
              <span className={cn("ml-0.5 font-mono text-[10px]", active ? "text-emerald-100/70" : "text-neutral-600")}>{i + 1}</span>
            </button>
          );
        })}
      </nav>

      <div className="ml-auto flex items-center gap-1 md:ml-0">
        <a
          href={popUrl ?? undefined}
          target="_blank"
          rel="noreferrer"
          title="open current view in a new tab (O)"
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium",
            popUrl ? "bg-neutral-800 text-neutral-200 hover:bg-neutral-700" : "pointer-events-none bg-neutral-800/40 text-neutral-600",
          )}
        >
          <Icon.External /> <span className="hidden sm:inline">new tab</span>
        </a>
        <Btn onClick={onReload} title="reload current view (R)">
          <Icon.Reload className={cn(polling && "animate-spin")} />
        </Btn>
        <Btn onClick={onFullscreen} title="fullscreen stage (F)">
          <Icon.Full />
        </Btn>
        <Btn onClick={onSettings} title="settings (,)">
          <Icon.Settings />
        </Btn>
      </div>
    </header>
  );
}
