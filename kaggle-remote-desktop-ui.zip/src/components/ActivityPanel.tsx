import type { Live } from "../lib/config";
import type { LogEntry } from "../hooks/useLive";
import { Btn } from "./ui";
import { cn } from "../utils/cn";

const color: Record<LogEntry["kind"], string> = {
  info: "text-neutral-400",
  ok: "text-emerald-400",
  warn: "text-amber-400",
  err: "text-red-400",
};

export function ActivityPanel({ log, live, onClear }: { log: LogEntry[]; live: Live; onClear: () => void }) {
  return (
    <div className="grid h-full min-h-0 grid-cols-1 lg:grid-cols-[1fr_380px]">
      <div className="flex min-h-0 flex-col">
        <div className="flex items-center gap-2 border-b border-neutral-800 bg-neutral-900/60 px-3 py-1.5">
          <span className="text-xs font-medium text-neutral-200">Activity</span>
          <span className="text-[11px] text-neutral-500">{log.length} events (this browser session)</span>
          <Btn variant="ghost" className="ml-auto" onClick={onClear}>clear</Btn>
        </div>
        <div className="min-h-0 flex-1 overflow-auto p-2 font-mono text-[11px]">
          {log.length === 0 && <div className="p-2 text-neutral-500">nothing yet</div>}
          {log.map((e, i) => (
            <div key={i} className="flex gap-3 rounded px-1 py-0.5 hover:bg-neutral-900">
              <span className="shrink-0 tabular-nums text-neutral-600">{new Date(e.t).toLocaleTimeString()}</span>
              <span className={cn("break-all", color[e.kind])}>{e.msg}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="flex min-h-0 flex-col border-t border-neutral-800 lg:border-l lg:border-t-0">
        <div className="border-b border-neutral-800 bg-neutral-900/60 px-3 py-1.5 text-xs font-medium text-neutral-200">live.json (raw)</div>
        <pre className="min-h-0 flex-1 overflow-auto p-3 font-mono text-[11px] leading-relaxed text-neutral-300">{JSON.stringify(live, null, 2)}</pre>
      </div>
    </div>
  );
}
