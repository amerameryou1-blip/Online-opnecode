import { useEffect, useState } from "react";
import type { Config, Live } from "../lib/config";
import { ago, fmtDateTime, fmtTime, repoPageUrl } from "../lib/hf";
import type { Status } from "../hooks/useLive";

interface Props {
  live: Live;
  status: Status;
  cfg: Config;
  lastPoll: number;
  nextPoll: number;
  onPoll: () => void;
}

function Item({ k, v, title }: { k: string; v: React.ReactNode; title?: string }) {
  return (
    <span className="flex items-center gap-1 whitespace-nowrap" title={title}>
      <span className="text-neutral-500">{k}</span>
      <span className="text-neutral-300">{v}</span>
    </span>
  );
}

export function StatusStrip({ live, status, cfg, lastPoll, nextPoll, onPoll }: Props) {
  const [, tick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);
  const next = Math.max(0, Math.ceil((nextPoll - Date.now()) / 1000));

  return (
    <div className="flex items-center gap-4 overflow-x-auto border-b border-neutral-800/80 bg-neutral-950 px-3 py-1 font-mono text-[11px] [scrollbar-width:thin]">
      <Item k="repo" v={<a className="text-emerald-400 hover:underline" href={repoPageUrl(cfg.repo)} target="_blank" rel="noreferrer">{cfg.repo}</a>} />
      <Item k="live.json" v={<a className="text-neutral-300 hover:text-white hover:underline" href={repoPageUrl(cfg.repo, "live.json")} target="_blank" rel="noreferrer">view</a>} />
      {status === "live" && (
        <>
          <Item k="started" v={fmtDateTime(live.started)} title={live.started ?? ""} />
          <Item k="deadline" v={fmtDateTime(live.deadline_utc)} title={live.deadline_utc ?? ""} />
          <Item k="last save" v={live.last_save ? `${fmtTime(live.last_save)} (${ago(live.last_save)})` : "—"} />
          {live.heartbeat && <Item k="heartbeat" v={ago(live.heartbeat)} />}
          {live.opencode_version && <Item k="opencode" v={live.opencode_version} />}
          {live.host && <Item k="host" v={live.host} />}
        </>
      )}
      {status === "ended" && <Item k="last save" v={fmtDateTime(live.last_save)} />}
      <span className="ml-auto flex items-center gap-2 whitespace-nowrap text-neutral-500">
        <span>polled {lastPoll ? ago(new Date(lastPoll).toISOString()) : "—"}</span>
        <span>·</span>
        <button onClick={onPoll} className="text-neutral-400 hover:text-white">
          next in {next}s ↻
        </button>
      </span>
    </div>
  );
}
