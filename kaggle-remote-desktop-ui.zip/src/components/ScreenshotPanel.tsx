import { useCallback, useEffect, useRef, useState } from "react";
import type { Config } from "../lib/config";
import { fetchBlobUrl, fmtDateTime, listScreenshots, type HfFile } from "../lib/hf";
import { Btn, Icon } from "./ui";
import { cn } from "../utils/cn";

export function ScreenshotPanel({ cfg, active }: { cfg: Config; active: boolean }) {
  const [files, setFiles] = useState<HfFile[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [img, setImg] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [auto, setAuto] = useState(false);
  const cache = useRef<Map<string, string>>(new Map());

  const refresh = useCallback(async () => {
    setBusy(true);
    setErr("");
    try {
      const list = await listScreenshots(cfg.repo, cfg.token);
      list.sort((a, b) => {
        // fixed-name screenshot first, then newest timestamped first
        if (a.path.endsWith("opencode_terminal_screenshot.png")) return -1;
        if (b.path.endsWith("opencode_terminal_screenshot.png")) return 1;
        return b.path.localeCompare(a.path);
      });
      setFiles(list);
      setSel((s) => s && list.some((f) => f.path === s) ? s : list[0]?.path ?? null);
      // the fixed-name file is overwritten in place -> always refetch it
      cache.current.delete("screenshots/opencode_terminal_screenshot.png");
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }, [cfg.repo, cfg.token]);

  useEffect(() => {
    if (active) void refresh();
  }, [active, refresh]);

  useEffect(() => {
    if (!active || !auto) return;
    const id = setInterval(() => void refresh(), 30000);
    return () => clearInterval(id);
  }, [active, auto, refresh]);

  useEffect(() => {
    if (!sel) return setImg(null);
    const hit = cache.current.get(sel);
    if (hit) return setImg(hit);
    let cancelled = false;
    setImg(null);
    fetchBlobUrl(cfg.repo, cfg.token, sel)
      .then((u) => {
        cache.current.set(sel, u);
        if (!cancelled) setImg(u);
      })
      .catch((e) => !cancelled && setErr(String(e)));
    return () => {
      cancelled = true;
    };
  }, [sel, cfg.repo, cfg.token, files]);

  const selFile = files.find((f) => f.path === sel);

  return (
    <div className="flex h-full min-h-0">
      <aside className="flex w-64 shrink-0 flex-col border-r border-neutral-800 bg-neutral-900/50">
        <div className="flex items-center gap-2 border-b border-neutral-800 px-2 py-1.5">
          <span className="text-xs font-medium text-neutral-200">screenshots/</span>
          <span className="text-[11px] text-neutral-500">{files.length}</span>
          <label className="ml-auto flex items-center gap-1 text-[11px] text-neutral-400">
            <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} className="accent-emerald-500" /> auto
          </label>
          <Btn variant="ghost" onClick={() => void refresh()} className="px-1.5" title="refresh list">
            <Icon.Reload className={cn(busy && "animate-spin")} />
          </Btn>
        </div>
        <div className="min-h-0 flex-1 overflow-auto">
          {files.length === 0 && !busy && <div className="p-3 text-xs text-neutral-500">No screenshots yet. Run <code>shot()</code> in the Kaggle cell to capture the tmux pane.</div>}
          {files.map((f) => (
            <button
              key={f.path}
              onClick={() => setSel(f.path)}
              className={cn("block w-full border-b border-neutral-800/60 px-2.5 py-1.5 text-left font-mono text-[11px] hover:bg-neutral-800/60", sel === f.path ? "bg-emerald-900/30 text-emerald-200" : "text-neutral-300")}
            >
              <div className="truncate">{f.path.replace("screenshots/", "")}</div>
              <div className="text-[10px] text-neutral-500">
                {(f.size / 1024).toFixed(0)} KB{f.lastCommit?.date ? ` · ${fmtDateTime(f.lastCommit.date)}` : ""}
              </div>
            </button>
          ))}
        </div>
      </aside>
      <div className="relative min-w-0 flex-1 overflow-auto bg-black p-3">
        {err && <div className="mb-2 rounded border border-yellow-900 bg-yellow-950/40 px-2 py-1 font-mono text-[11px] text-yellow-200">{err}</div>}
        {sel && !img && !err && <div className="text-xs text-neutral-500">loading…</div>}
        {img && (
          <>
            <img src={img} alt={sel ?? ""} className="max-w-full rounded border border-neutral-800" />
            <div className="mt-2 flex items-center gap-3 font-mono text-[11px] text-neutral-500">
              <span>{sel}</span>
              {selFile?.lastCommit?.date && <span>committed {fmtDateTime(selFile.lastCommit.date)}</span>}
              <a href={img} download={sel?.split("/").pop()} className="text-emerald-400 hover:underline">download</a>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
