import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { loadConfig, saveConfig, type Config, type ViewId, VIEWS } from "./lib/config";
import { useLive } from "./hooks/useLive";
import { TopBar } from "./components/TopBar";
import { StatusStrip } from "./components/StatusStrip";
import { OfflineOverlay } from "./components/OfflineOverlay";
import { CellPanel } from "./components/CellPanel";
import { ScreenshotPanel } from "./components/ScreenshotPanel";
import { ActivityPanel } from "./components/ActivityPanel";
import { SettingsDrawer } from "./components/SettingsDrawer";
import { Kbd } from "./components/ui";
import { cn } from "./utils/cn";

const FRAME_VIEWS = ["term", "web", "files"] as const;
type FrameView = (typeof FRAME_VIEWS)[number];
const liveKey: Record<FrameView, "terminal" | "web" | "files"> = { term: "terminal", web: "web", files: "files" };

export default function App() {
  const [cfg, setCfg] = useState<Config>(() => loadConfig());
  const [view, setView] = useState<ViewId>(() => (sessionStorage.getItem("oc_view") as ViewId) || "term");
  const [settings, setSettings] = useState(false);
  const [frameKeys, setFrameKeys] = useState<Record<FrameView, number>>({ term: 0, web: 0, files: 0 });
  const [loaded, setLoaded] = useState<Record<FrameView, boolean>>({ term: false, web: false, files: false });
  const stageRef = useRef<HTMLDivElement>(null);
  const { live, status, error, lastPoll, nextPoll, polling, log, poll, push, clearLog } = useLive(cfg);

  useEffect(() => sessionStorage.setItem("oc_view", view), [view]);

  const urlFor = useCallback((v: ViewId): string | null => (v in liveKey ? live[liveKey[v as FrameView]] : null), [live]);
  const popUrl = urlFor(view);

  const reload = useCallback(() => {
    if (view in liveKey && urlFor(view)) {
      setFrameKeys((k) => ({ ...k, [view]: k[view as FrameView] + 1 }));
      setLoaded((l) => ({ ...l, [view]: false }));
      push("info", `reloaded ${view} frame`);
    } else void poll();
  }, [view, urlFor, poll, push]);

  const fullscreen = useCallback(() => {
    const el = stageRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  }, []);

  const saveCfg = (c: Config) => {
    saveConfig(c);
    setCfg(c);
    setSettings(false);
    push("info", "settings saved");
  };

  // keyboard shortcuts (ignored while typing in inputs)
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const n = Number(e.key);
      if (n >= 1 && n <= VIEWS.length) return setView(VIEWS[n - 1].id);
      if (e.key === "r" || e.key === "R") return reload();
      if (e.key === "f" || e.key === "F") return fullscreen();
      if (e.key === ",") return setSettings((s) => !s);
      if (e.key === "Escape") return setSettings(false);
      if ((e.key === "o" || e.key === "O") && popUrl) window.open(popUrl, "_blank");
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [reload, fullscreen, popUrl]);

  const frameMissing = view in liveKey && !urlFor(view);
  const showOverlay = frameMissing || (status === "connecting" && view in liveKey);

  const title = useMemo(() => `${status === "live" ? "●" : "○"} OpenCode @ Kaggle`, [status]);
  useEffect(() => {
    document.title = title;
  }, [title]);

  return (
    <div className="flex h-full flex-col bg-neutral-950 text-neutral-200">
      <TopBar
        status={status}
        error={error}
        live={live}
        view={view}
        onView={setView}
        popUrl={popUrl}
        onReload={reload}
        onFullscreen={fullscreen}
        onSettings={() => setSettings(true)}
        polling={polling}
      />
      <StatusStrip live={live} status={status} cfg={cfg} lastPoll={lastPoll} nextPoll={nextPoll} onPoll={() => void poll()} />

      <main ref={stageRef} className="relative min-h-0 flex-1 bg-black">
        {FRAME_VIEWS.map((v) => {
          const url = live[liveKey[v]];
          const visible = view === v;
          return (
            <div key={v} className={cn("absolute inset-0", !visible && "invisible")}>
              {url ? (
                <>
                  {!loaded[v] && (
                    <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black text-xs text-neutral-500">
                      <span className="h-2 w-2 animate-ping rounded-full bg-emerald-400" /> connecting to {url}
                    </div>
                  )}
                  <iframe
                    key={frameKeys[v]}
                    src={url}
                    title={v}
                    onLoad={() => setLoaded((l) => ({ ...l, [v]: true }))}
                    allow="clipboard-read; clipboard-write; fullscreen"
                    className="h-full w-full border-0 bg-black"
                  />
                </>
              ) : null}
            </div>
          );
        })}

        <div className={cn("absolute inset-0", view !== "shots" && "hidden")}>
          <ScreenshotPanel cfg={cfg} active={view === "shots"} />
        </div>
        {view === "cell" && (
          <div className="absolute inset-0">
            <CellPanel cfg={cfg} onSettings={() => setSettings(true)} />
          </div>
        )}
        {view === "activity" && (
          <div className="absolute inset-0">
            <ActivityPanel log={log} live={live} onClear={clearLog} />
          </div>
        )}

        {showOverlay && (
          <OfflineOverlay
            status={status}
            live={live}
            error={error}
            pollSec={cfg.pollSec}
            onShowCell={() => setView("cell")}
            onSettings={() => setSettings(true)}
            onPoll={() => void poll()}
          />
        )}
      </main>

      <footer className="flex items-center gap-3 border-t border-neutral-800 bg-neutral-900/80 px-3 py-1 text-[10px] text-neutral-500">
        <span className="hidden items-center gap-1 sm:flex">
          <Kbd>1</Kbd>–<Kbd>6</Kbd> views <Kbd>R</Kbd> reload <Kbd>F</Kbd> fullscreen <Kbd>O</Kbd> new tab <Kbd>,</Kbd> settings
        </span>
        <span className="ml-auto">
          {status === "live" && live.mode === "interactive" && "interactive mode: keep the Kaggle tab open, or use Save & Run All for 12 h headless"}
          {status === "live" && live.mode === "batch" && "batch mode: headless, safe to close Kaggle"}
          {status !== "live" && "tunnels via Cloudflare quick tunnels · state on Hugging Face"}
        </span>
      </footer>

      <SettingsDrawer open={settings} cfg={cfg} onClose={() => setSettings(false)} onSave={saveCfg} />
    </div>
  );
}
